## Version 1.0.0 (5 aug 2019)
- Initial template
- Bootstrap version 3.3.7

## Version 1.1.0 (5 dec 2019)
- Remove extra plugins
- Fix dropdown issue
- Customize portfolio page
- Added new google map